﻿Public Class InterruttoreEventArgs
    Inherits EventArgs

    Public state As String
End Class

